import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ExportTableComponent } from './components/export-table.component';
import { DataTableModule, MultiSelectModule, DropdownModule  } from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { CarService } from './components/carService'
import { HttpModule} from '@angular/http';
  
@NgModule({
  declarations: [
    AppComponent, ExportTableComponent
  ],
  imports: [
    BrowserModule, DataTableModule, MultiSelectModule, TableModule, HttpModule, DropdownModule, FormsModule, 
    RouterModule.forRoot([
      { path: 'welcome', component: ExportTableComponent }])
  ],
  providers: [CarService],
  bootstrap: [AppComponent]
})
export class AppModule { }
