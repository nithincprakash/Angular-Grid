
import { Component, OnInit, Input } from '@angular/core'
import { CarService } from './carService'
import {Car} from './domain/car'
import { Key } from 'selenium-webdriver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
//import * as jsPDF from 'jspdf'
//import * as autoTable from 'jspdf-autotable'
var jsPDF = require('jspdf');
require('jspdf-autotable');
const ExportJsonExcel = require('js-export-excel');

@Component({
  selector: 'export-table',
  templateUrl: './export-table.component.html'
})
export class ExportTableComponent implements OnInit {
  @Input() data: any[];
  @Input() name: string;
  tableData: any[];
  selectedData: any[];
  column: any[] = [];
  cols: any[];
  col: any[];
  selectedColumns: any[];
  documentName: string;
  pickedData: any[]

  constructor(private carService: CarService) { }

  ngOnInit() {
    console.log(this.data);
    this.col = [];
    this.cols = [];
    this.tableData = this.data;
    this.column = Object.keys(this.data[0]);
    this.column.forEach(c => {
      this.col.push({ title: c, dataKey: c });
      this.cols.push({ field: c, header: c });
    });
    this.selectedColumns = this.cols;
    this.documentName = this.name;
  }
  downloadPdf(selectedColumns: any[]) {
    let fileteredData = this.filterData(selectedColumns);
    var doc = new jsPDF('p', 'pt');
    doc.autoTable(selectedColumns, fileteredData, {
      styles: { fillColor: [100, 255, 255] },
      columnStyles: {
        id: { fillColor: 255 }
      },
      margin: { top: 60 },
      addPageContent: function (data) {
        doc.text("Header", 40, 30);
      }
    });
    doc.save(this.documentName + '.pdf');

  }

  downloadExcel(selectedColumns: any[]) {
    let selected = [];
    selectedColumns.forEach((row) => selected.push(row.field));
    let fileteredData = this.filterData(selectedColumns);
    var option = {fileName: this.documentName, datas: []};

    option.fileName = 'excel'
    option.datas = [
      {
        sheetData: fileteredData,
        sheetName: 'sheet',
        sheetHeader: selected
      },
      {
        sheetData: fileteredData
      }
    ];

    var toExcel = new ExportJsonExcel(option); 
    toExcel.saveExcel(); 
  }

  downloadCsv(selectedColumns: any[]) {
    let fileteredData = this.filterData(selectedColumns);
    new Angular2Csv(fileteredData, this.documentName);
  }

  filterData(selectedColumns: any[]) :any[] {
    let selected = [];
    selectedColumns.forEach((row) => selected.push(row.field));
    var filteredData = [];
    this.tableData.forEach((row) => {
      filteredData.push(this.getSubset(selected, row));
    });
    return filteredData;
  }
  getSubset = (keys, obj) => keys.reduce((a, c) => ({ ...a, [c]: obj[c] }), {});

}
